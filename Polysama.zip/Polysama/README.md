# What does this Repo?
This Repo contains an ansible Playbook, that will install two instances of a Kusama Validator on your Debian/Ubuntu Server.

# How to use this Playbook?

## Requirements:
To use this Playbook you need:
- ssh access to a Machine with a user that has root permissions
- ansible installed on the Machine you want to execute the Playbook from
- declare some Varibales
- open the TCP Ports 30344 and 30345 to the Internet

## Variables to declare
### In the file 'group_vars/all.yml' you can change this variables:
- system_username
- kusama_username
- version

### Examples and explanation
#### system_username
Thats the username of your Ubuntu/Debian User.
If you login into your System for example with the command 'ssh kusama@<IP-ADDRESS>' your system_username is 'kusama'.   
```
system_username: kusama
```

#### kusama_username
Thats the Name your Kusama Validator and their systemd services will have.   
As this Playbook will install you two instances/services of a Kusama Validator, the Names are numbered with '-1' and '-2'.
Open this website, switch to Kusama and check if your desired Validator Names arent already taken:
[Telemtery Polkadot](https://telemetry.polkadot.io/#list/0xb0a8d493285c2df73290dfb7e61f870f17b41801197a149ca93654499ea3dafe)
```
kusama_username: some-name-you-like
```

#### version
Thats the Version you want to run for the Validatpor.
Check whats the latest Version here [GitHub Polkadot](https://github.com/paritytech/polkadot-sdk/releases)
```
version: 1.7.0
```

### In the file 'inventory.yml' you need to change this variables:
- ansible_host

### Examples and explanation
#### ansible_host
Thats the IP-Address of your Target Machine.
Your Machine needs to be accessable using ssh with that IP.
```
ansible_host: 192.168.1.10
```

# Run the Playbook
## Execute Ansible
cd into this Repo and run the Playbook with 'ansible-playbook playbook.yml'

## Check your Machine after the run
Have a look in the logs of your newly created Services with 'journalctl -fu kusama-<kusama_username>-1' and 'journalctl -fu kusama-<kusama_username>-2'.   
Replace  <kusama_username> with the kusama_username you have used in this Playbook.   
The output should look something like this:
```
⚙️  Syncing 512.4 bps, target=#21918507 (23 peers), best: #1797340 (0x08d0…3cab), finalized #1797203 (0x8387…60f2), ⬇ 417.2kiB/s ⬆ 127.9kiB/s
⚙️  Syncing 423.0 bps, target=#21918508 (23 peers), best: #1799455 (0x0691…446c), finalized #1799168 (0x5440…9498), ⬇ 274.0kiB/s ⬆ 98.4kiB/s
⚙️  Syncing 520.5 bps, target=#21918509 (23 peers), best: #1802060 (0x33db…c62b), finalized #1800710 (0xe30c…3aef), ⬇ 382.8kiB/s ⬆ 111.6kiB/s
⚙️  Syncing 508.6 bps, target=#21918510 (23 peers), best: #1804603 (0x3050…af00), finalized #1804288 (0x5b5f…2431), ⬇ 397.5kiB/s ⬆ 131.6kiB/s
⚙️  Syncing 551.4 bps, target=#21918511 (23 peers), best: #1807360 (0x1746…98f8), finalized #1806336 (0x179a…544e), ⬇ 334.0kiB/s ⬆ 98.3kiB/s
⚙️  Syncing 589.2 bps, target=#21918512 (23 peers), best: #1810306 (0xf52a…c99a), finalized #1809920 (0x21ea…fdf8), ⬇ 395.2kiB/s ⬆ 110.6kiB/s
```